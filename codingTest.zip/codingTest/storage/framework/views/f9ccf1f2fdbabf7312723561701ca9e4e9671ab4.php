<span class="float-start">
    <a href="/candidate/create">
        <button class="btn btn-primary">+ Add</button>
    </a>
</span>
<table class="table table-striped table-success">
    <thead>
        <tr>
            <th>Name</th>
            <th>Education</th>
            <th>Birthday</th>
            <th>Experience</th>
            <th>Last Position</th>
            <th>Applied Position</th>
            <th>Top 5 Skills</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Resume</th>
            <th>#</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $dataCalon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><a href="/candidate/<?php echo e($item->id); ?>"><?php echo e($item->name); ?></a></td>
                <td><?php echo e($item->education); ?></td>
                <td><?php echo e($item->birthday); ?></td>
                <td><?php echo e($item->experience); ?></td>
                <td><?php echo e($item->lastPosition); ?></td>
                <td><?php echo e($item->appliedPosition); ?></td>
                <td><?php echo e($item->top5); ?></td>
                <td><?php echo e($item->email); ?></td>
                <td><?php echo e($item->phone); ?></td>
                <td>
                    <a href="<?php echo e($item->resume); ?>" target="_blank">CV <?php echo e($item->name); ?></a>
                </td>
                <td>
                    <i class="fa-solid fa-trash text-danger"></i>&nbsp;
                    <a href="/candidate/<?php echo e($item->id); ?>/edit">
                        <i class="fa-solid fa-pencil text-primary"></i>
                    </a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH D:\Zul\testCoding\codingTest\resources\views/admin.blade.php ENDPATH**/ ?>