<span class="float-start">
    <a href="/candidate/create">
        <button class="btn btn-primary">+ Add</button>
    </a>
</span>
<table class="table table-striped table-success">
    <thead>
        <tr>
            <th>Name</th>
            <th>Education</th>
            
            <th>Experience</th>
            
            <th>Applied Position</th>
            
            <th>Email</th>
            <th>Phone</th>
            <th>Resume</th>
            <th style="width: 90px;">#</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $dataCalon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><a href="/candidate/<?php echo e($item->id); ?>"><?php echo e($item->name); ?></a></td>
                <td><?php echo e($item->education); ?></td>
                
                <td><?php echo e($item->experience); ?></td>
                
                <td><?php echo e($item->appliedPosition); ?></td>
                
                <td><?php echo e($item->email); ?></td>
                <td><?php echo e($item->phone); ?></td>
                <td>
                    <?php if($item->resume!=''): ?>
                    <a href="/storage/<?php echo e($item->resume); ?>" target="_blank">CV <?php echo e($item->name); ?></a>
                    <?php else: ?>
                        Not Available
                    <?php endif; ?>                    
                </td>
                <td>
                    <form action="/candidate/<?php echo e($item->id); ?>" method="post" class="">
                        <?php echo method_field('delete'); ?>
                        <?php echo csrf_field(); ?>
                        <button class="btn bg-none" style="padding-bottom:10px;" onclick="return confirm('Yakin Hapus Data?')"><i class="fa-solid fa-trash text-danger"></i></button>&nbsp;
                        <a href="/candidate/<?php echo e($item->id); ?>/edit">
                            <i class="fa-solid fa-pencil text-primary"></i>
                        </a>
                    </form>                    
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\Users\zul03\Documents\testCoding\codingTest\resources\views/admin.blade.php ENDPATH**/ ?>