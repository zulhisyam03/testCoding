<table class="table table-striped table-success">
    <thead>
        <tr>
            <th>Name</th>
            <th>Education</th>
            <th>Birthday</th>
            <th>Experience</th>
            <th>Last Position</th>
            <th>Applied Position</th>
            <th>Top 5 Skills</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Resume</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $dataCalon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><a href="/candidate/<?php echo e($item->id); ?>"><?php echo e($item->name); ?></a></td>
                <td><?php echo e($item->education); ?></td>
                <td><?php echo e($item->birthday); ?></td>
                <td><?php echo e($item->experience); ?></td>
                <td><?php echo e($item->lastPosition); ?></td>
                <td><?php echo e($item->appliedPosition); ?></td>
                <td><?php echo e($item->top5); ?></td>
                <td><?php echo e($item->email); ?></td>
                <td><?php echo e($item->phone); ?></td>
                <td>
                    <?php if($item->resume!=''): ?>
                    <a href="/storage/<?php echo e($item->resume); ?>" target="_blank">CV <?php echo e($item->name); ?></a>
                    <?php else: ?>
                        Not Available
                    <?php endif; ?> 
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\Users\zul03\Documents\testCoding\codingTest\resources\views/user.blade.php ENDPATH**/ ?>